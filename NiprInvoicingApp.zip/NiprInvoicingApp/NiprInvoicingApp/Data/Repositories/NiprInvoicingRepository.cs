﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer.Extensions;
using NiprInvoicingApp.Model;

namespace DataAccessLayer
{
    public class NiprInvoicingRepository : Repository<NiprInvoicing>
    {
        private DbContext _context;
        public NiprInvoicingRepository(DbContext context)
            : base(context)
        {
            _context = context;
        }

        public IList<NiprInvoicing> GetNiprInvoicings(DateTime fromDate, DateTime toDate)
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "Nipr_Invoicing";

                command.Parameters.Add(command.CreateParameter("@From_Date", fromDate));
                command.Parameters.Add(command.CreateParameter("@To_Date", toDate));

                return this.ToList(command).ToList();
            }
        }
        
    }
}
