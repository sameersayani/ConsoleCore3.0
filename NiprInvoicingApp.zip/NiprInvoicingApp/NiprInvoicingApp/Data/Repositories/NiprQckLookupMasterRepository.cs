﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer.Extensions;
using NiprInvoicingApp.Model;

namespace DataAccessLayer
{
    public class NiprQckLookupMasterRepository : Repository<NiprInvoicing>
    {
        private DbContext _context;
        public NiprQckLookupMasterRepository(DbContext context)
            : base(context)
        {
            _context = context;
        }

        public IList<NiprInvoicing> GetNiprQckLookupMaster(DateTime fromDate, DateTime toDate)
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "Nipr_QckLookupMaster";

                command.Parameters.Add(command.CreateParameter("@From_Date", fromDate));
                command.Parameters.Add(command.CreateParameter("@To_Date", toDate));

                return this.ToList(command).ToList();
            }
        }
        
    }
}
