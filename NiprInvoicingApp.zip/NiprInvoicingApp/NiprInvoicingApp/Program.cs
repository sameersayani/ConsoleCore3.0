﻿using DataAccessLayer;
using NiprInvoicingApp.Model;
using System;
using System.Collections.Generic;

namespace NiprInvoicingApp
{
    class Program
    {
        private static IConnectionFactory connectionFactory;
        static void Main(string[] args)
        {
            Console.WriteLine("NIPR Invoice Generator Started...");
            Console.Write("Please enter Start Date (mm/dd/yyyy) :");
            var startDate = Console.ReadLine();
            Console.Write("Please enter End Date (mm/dd/yyyy) :");
            var endDate = Console.ReadLine();
            var parserStart = DateTime.Parse(startDate);
            var parserEnd = DateTime.Parse(endDate);
            if(parserStart > parserEnd)
            {
                Console.WriteLine("ERROR :: Start Date cannot be greater than End Date");
                Console.WriteLine("Please enter Start Date (mm/dd/yyyy) :");
                startDate = Console.ReadLine();
                Console.WriteLine("Please enter End Date (mm/dd/yyyy) :");
                endDate = Console.ReadLine();
            }

            var lst = GetNiprInvoicing(parserStart, parserEnd);
        }

        private static IList<NiprInvoicing> GetNiprInvoicing(DateTime from, DateTime to)
        {
            connectionFactory = ConnectionHelper.GetConnection();
            var conext = new DbContext(connectionFactory);
            var niprInvoice = new NiprInvoicingRepository(conext);
            return niprInvoice.GetNiprInvoicings(from, to);
        }
    }
}
